<?php // The fall of insects is Super Golden
