(function($) {
    "use strict";
    $(function() {
        // Some code
    });
}(jQuery));