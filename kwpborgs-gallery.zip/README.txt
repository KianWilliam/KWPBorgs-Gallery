=== KWPBorgs Gallery ===
Contributors: KianWilliam
Donate link:https://www.extensions.kwproductions121.com/wordpress/kwpborgs-gallery.html
Tags: galleries, images
Requires at least: 5.0.0
Tested up to: 6.5.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

KWPBorgs Gallery is a 3D gallery in the shape of a cube.

== Description ==

Each dimension of the cube reveals an image but the bottom and top, the cube moves around y-axis .

= Plugin Features =

You may upload certain amount of images, the width and height of each image must be divisible by
chosen columns and rows, you could move each dimension horizontally or vertically and also 
the speed of movement both cube and dimension could be set up.

== Installation ==

1. Upload `kwpborgs-gallery.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress


== Credits ==

2. WP Color Picker Alpha(https://github.com/23r9i0/wp-color-picker-alpha)
 
